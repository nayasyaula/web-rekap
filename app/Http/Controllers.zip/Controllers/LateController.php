<?php

namespace App\Http\Controllers;

use App\Models\Late;
use Illuminate\Http\Request;

class LateController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $late = Late::all();
        return view('lates.index', compact('late'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('lates.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'date_time_late' => 'required',
            'information' => 'required',
            'bukti' => 'required',
        ]);

        $late = Late::create($request->except('file'));

        if ($request->hasFile('file') && $request->file('file')->isValid()) {
            $late->addMediaFromRequest('file')->toMediaCollection('file');
        }

        return redirect()->back()->with('succses', 'Berhasil menambahkan data keterlambatan');
    }

    /**
     * Display the specified resource.
     */
    public function show(Late $late)
    {
        return view('lates.show', compact('late'));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Late $late, $id)
    {
        $late = Late::find($id);

        return view('lates.edit', compact('late'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Late $late)
    {
        $request->validate([
            'date_time_late' => 'required',
            'information' => 'required',
            'bukti' => 'required',
        ]);

        $late = Late::create($request->except('file'));

        if ($request->hasFile('file') && $request->file('file')->isValid()) {
            $late->addMediaFromRequest('file')->toMediaCollection('file');
        }

        return redirect()->route('late.home')->with('succses', 'Berhasil mengubah data keterlambatan');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Late $late, $id)
    {
        Late::where('id', $id)->delete();

        return redirect()->back()->with('deleted', 'Berhasil menghapus data!');
    }
}
